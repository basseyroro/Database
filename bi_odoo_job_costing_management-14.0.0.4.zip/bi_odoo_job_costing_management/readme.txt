Version: 14.0.0.0 --> migrate bi_odoo_job_costing_management in v14

14.0.0.1 --> Fixed issue in chatter from website

14.0.0.2 --> Added chatter in job.cost.sheet and job.order form view to upload documents.

14.0.0.3 --> Fixed _prepare_account_move_line() method of job_costing_management.py

14.0.0.4 --> Fixed mixins inherited in job.cost.sheet and job.order model for chatter in job_costing_management.py
