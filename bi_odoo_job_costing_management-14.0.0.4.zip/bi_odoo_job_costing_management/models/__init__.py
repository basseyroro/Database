# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import job_costing_management
from . import project_issue
from . import res_partner
from . import purchase_requisition
from . import project_project

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
